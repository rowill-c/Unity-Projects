# Prototype-3
Unit 3 - Sound and Effects Bu bölümde, oyuncu karşısına gelen engellerden zıplayarak kaçmaya çalışacaktır. AudioSource ve Partical Effect lerin script içinde kullanımı gösterilmektedir.

![](prototype-3.gif)
